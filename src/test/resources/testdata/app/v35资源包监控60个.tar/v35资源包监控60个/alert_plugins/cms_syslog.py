# -*- coding: utf-8 -*-
# wu.ranbo@yottabyte.cn
# 2016-06-17
# Copyright 2016 Yottabyte
# filename: custom/cmschina/apps/alert/plugins/cms_syslog.py
# file description: syslog插件，默认插件
__author__ = 'wu.ranbo'

from django.template import Context, Template
import logging
import logging.handlers
import socket
import html.parser

re_logger = logging.getLogger("django.request")
global reply_content
reply_content = ""
log_content = {
    logging.FATAL: re_logger.fatal,
    logging.ERROR: re_logger.error,
    logging.WARNING: re_logger.warning,
    logging.INFO: re_logger.info,
    logging.DEBUG: re_logger.debug
}

# getLogger得到的是singleton
syslogger = logging.getLogger('AlertPluginSyslog')
syslogger.setLevel(logging.DEBUG)

META = {
    "name": "cms_syslog",
    "version": 1,
    "alias": "syslog告警",
    "configs": [
        {
            "name": "addresses",
            "alias": "Syslog地址",
            "placeholder": "",
            "presence": True,
            "value_type": "string",
            "default_value": "",
            "style": {
                "rows": 1,
                "cols": 15
            }
        },
        {
            "name": "socktype",
            "alias": "发送协议",
            "placeholder": "",
            "presence": True,
            "value_type": "string",
            "input_type": "drop_down",
            "input_candidate": ["TCP", "UDP"],
            "default_value": "UDP",
            "style": {
                "rows": 1,
                "cols": 15
            }
        },
        {
            "name": "serverity",
            "alias": "Serverity",
            "placeholder": "",
            "presence": True,
            "value_type": "string",
            "input_type": "drop_down",
            "input_candidate": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
            "default_value": "INFO",
            "style": {
                "rows": 1,
                "cols": 15
            }
        },
        {
            "name": "facility",
            "alias": "Facility",
            "placeholder": "",
            "presence": True,
            "value_type": "string",
            "default_value": "local0",
            "style": {
                "rows": 1,
                "cols": 15
            }
        },
        {
            "name": "message",
            "alias": "Syslog内容",
            "placeholder": "",
            "presence": True,
            "value_type": "string",
            "style": {
                "rows": 5,
                "cols": 60
            },
            "default_value": "{{ alert.name }}|{{ alert.strategy.trigger.start_time|date:\"Y-m-d H:i:s\" }}|{{ alert.strategy.trigger.end_time|date:\"Y-m-d H:i:s\" }}|{{ alert.search.query }}"
        }
    ]
}


# 调用处有整体裹起来的异常处理
def handle(params, alert):
    try:
        _content = content(params, alert)
        html_parser = html.parser.HTMLParser()
        message = html_parser.unescape(_content)
        re_logger.info("message: %s" % message)
        configs = params.get('configs')
        address = configs[0].get('value')
        s_type = configs[1].get('value').lower()
        serverity = configs[2].get('value').lower()
        facility = configs[3].get('value').lower()

        arr = address.split(':')
        if len(arr) != 2:
            log_and_reply(logging.ERROR, ("syslog alert config address wrong!"))
            raise "syslog alert config address wrong!"
        ip = arr[0]
        port = int(arr[1])

        socket_type = socket.SOCK_DGRAM
        if s_type == 'tcp':   # 其他都是udp
            socket_type = socket.SOCK_STREAM

        log_handler = logging.handlers.SysLogHandler(address=(ip, port),
                                                facility=facility,
                                                socktype=socket_type)

        syslogger.addHandler(log_handler)
        if serverity == 'debug':
            syslogger.debug(message)
        elif serverity == 'info':
            syslogger.info(message)
        elif serverity == 'warning':
            syslogger.warning(message)
        elif serverity == 'error':
            syslogger.error(message)
        elif serverity == 'critical':
            syslogger.critical(message)
        else:
            log_and_reply(logging.ERROR, ("alert:%s use a illegal syslog serverity %s", alert["name"], serverity))
            syslogger.info(message)

        log_handler.flush()  # flush保证
        log_handler.close()  # 主动关闭socket
        syslogger.removeHandler(log_handler)
        log_and_reply(logging.INFO, ("syslog plugin run success!!!"))
    except Exception as e:
        log_and_reply(logging.ERROR, ("alert.plugins.syslog got exception %s", e))
        raise e

def content(params, alert):
    configs = params.get('configs')
    template_str = configs[4].get('value')
    conf_obj = {}
    conf_obj['alert'] = alert
    return _render(template_str, conf_obj)

def _render(tmpl_str, conf_obj):
    t = Template(tmpl_str)
    c = Context(conf_obj)
    return t.render(c)

# 既在日志中打印，又在执行结果中显示
def log_and_reply(log_level, comment):
    global reply_content
    log_content.get(log_level)(comment)
    reply_content = '%s%s%s' % (reply_content, "\n", comment)

# 获取执行结果的接口 
def execute_reply(params, alert):
    re_logger.info("reply_content start")
    handle(params, alert)  
    re_logger.info("reply_content: %s" % (reply_content))
    return reply_content