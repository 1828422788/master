# -*- coding: utf-8 -*-
# wu.ranbo@yottabyte.cn
# 2016-05-19
# Copyright 2016 Yottabyte
# filename: yottaweb/apps/alert/plugins/alert_email.py
# file description: 邮件告警插件，默认插件，目前是支持用户分组及附件趋势图
__author__ = 'wu.ranbo'

from django.template import Context, Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders
from yottaweb.apps.utils.resources import MyUtils

import json,urllib.request,urllib.parse,urllib.error,urllib.request,urllib.error,urllib.parse
import configparser
import smtplib
import logging
import os
import base64

re_logger = logging.getLogger("django.request")
global reply_content
reply_content = ""
log_content = {
    logging.FATAL: re_logger.fatal,
    logging.ERROR: re_logger.error,
    logging.WARNING: re_logger.warning,
    logging.INFO: re_logger.info,
    logging.DEBUG: re_logger.debug
}
#发送方式的类型，对应三个样例。
# 样例一：connect；样例二：common；样例三：starttls。
# 默认的是样例2，所以是common。如果跑不通，能跑通哪个样例，替换哪个样例对应的代号。
send_type = "common"

META = {
        "name": "email",
        "version": 1,
        "alias": "邮件告警",
        "configs": [
            {
                "name": "subject",
                "alias": "标题",
                "placeholder": "支持模板语言",
                "presence": True,
                "value_type": "string",
                "default_value": "[告警邮件][{%if alert.is_alert_recovery %}告警恢复{% else %}{% if alert.strategy.trigger.level == \"low\" %}低{% elif alert.strategy.trigger.level == \"mid\" %}中{%elif alert.strategy.trigger.level == \"high\"%}高{% endif %}{% endif %}]{% autoescape off %}{{alert.name}}{% endautoescape %}",
                "style": {
                    "rows": 1,
                    "cols": 15
                }
            },
            {
                "name": "receiver",
                "alias": "接收者",
                "placeholder": "可以是个人邮箱，也可以是用户分组",
                "presence": True,
                "value_type": "string",
                "input_type": "email_account_group",
                "default_value": "",
                "style": {
                    "rows": 1,
                    "cols": 20
                }
            },
            {
                "name": "content_tmpl",
                "alias": "内容模板",
                "placeholder": "",
                "presence": True,
                "value_type": "template",
                "default_value": """
<br>
{% if alert.is_alert_recovery %}
告警{{ alert.name }}已经恢复。<br><br>
{% else %}
告警名称: {{ alert.name }}<br>
告警级别：{% if alert.strategy.trigger.level == "low" %}低{% elif alert.strategy.trigger.level == "mid" %}中{%elif alert.strategy.trigger.level == "high"%}高{% endif %}<br>
告警描述: {{ alert.description | safe }}<br>
告警产生时间: {{ alert.send_time|date:"Y年n月d日 H:i:s" }}<br>
告警时间范围: {{ alert.strategy.trigger.start_time|date:"Y年n月d日 H:i:s" }}到{{ alert.strategy.trigger.end_time|date:"Y年n月d日 H:i:s" }}<br>
查询语句: {{ alert.search.query }}<br>
过滤条件: {{ alert.search.filter}}<br><br>
查询链接: <a href={{web_conf.custom.web_address}}/search/?datasets={{ alert.search.datasets|urlencode }}&time_range={{alert.strategy.trigger.start_time|date:"Uu"|slice:":-3"}},{{alert.strategy.trigger.end_time|date:"Uu"|slice:":-3"}}&filters={{ alert.search.filter|urlencode}}&query={{alert.search.query|urlencode}}&title={{alert.name|urlencode}}&_t={{alert.send_time|date:"Uu"|slice:":-3"}}&page=1&size=20&order=desc&index=new>{{web_conf.custom.web_address}}/search/?datasets={{ alert.search.datasets|urlencode }}&time_range={{alert.strategy.trigger.start_time|date:"Uu"|slice:":-3"}},{{alert.strategy.trigger.end_time|date:"Uu"|slice:":-3"}}&filters={{ alert.search.filter|urlencode}}&query={{alert.search.query|urlencode}}&title={{alert.name|urlencode}}&_t={{alert.send_time|date:"Uu"|slice:":-3"}}&page=1&size=20&order=desc&index=new</a><br>
<br>
 {% if alert.extend_conf %}
    扩展配置: {% for key,value in alert.extend_conf.items %}
   <li> {{key}}:{{value}}</li>
    {% endfor %}
  {% endif %}
<br>
{% if alert.strategy.name == "count"  %}
触发条件：{{ alert.strategy.trigger.compare_desc_text }}<br>
触发事件总数：{{ alert.result.total }}<br><br>
{% if alert.is_segmentation %}
切分字段: {{ alert.segmentation_field }}<br>
触发设备: {{ alert.segmentation_specify_value }}<br><br>
{% endif %}
最近事件：<br>
  {% if alert.result.hits %}
    {% for hit in alert.result.hits %}
      {% if hit.appname %} appname:{{ hit.appname }}, {% endif %}
      {% if hit.tag %} tag:{{ hit.tag|join:";" }}, {% endif %}
      {% if hit.hostname %} hostname:{{ hit.hostname }}, {% endif %}
      {% if alert.is_segmentation %}
        {% if not alert.segmentation_field == "appname" %}
        {% if not alert.segmentation_field == "tag" %}
        {% if not alert.segmentation_field == "hostname" %}
          {{ alert.segmentation_field }} : {{ alert.segmentation_specify_value }}
        {% endif %}
        {% endif %}
        {% endif %}
      {% endif %}
    <br>
    {{ hit.raw_message }} <br>
     --------------------------------------------<br><br>
    {% endfor %}
  {% endif %}

{% elif alert.strategy.name == "field_stat" %}
  触发条件： {{ alert.strategy.trigger.compare_desc_text }}<br>
  {% if alert.is_segmentation %}
  切分字段: {{ alert.segmentation_field }}<br>
  触发设备: {{ alert.segmentation_specify_value }}<br>
  {% endif %}
  {% if alert.strategy.trigger.method == "cardinality" %}
    超过阈值的结果:<br>
    <table>
    <tr><td>键值:</td><td> 次数:</td></tr>
    {% for b in alert.result.terms %}
      {% if b.doc_count > alert.strategy.trigger.compare_value|first %}
      <tr><td>{{ b.key|ljust:"40" }}</td><td>{{ b.doc_count|ljust:"40" }}</td></tr>
      {% endif %}
    {% endfor %}
   </table>
  {% else %}
  {{ alert.strategy.trigger.field }}的值为{{ alert.result.value }}<br>
  {% endif %}

{% elif alert.strategy.name == "sequence_stat" %}
触发条件： {{ alert.strategy.trigger.compare_desc_text }}<br>

{% elif alert.strategy.name == "baseline_cmp" %}

基线的时间范围：{{ alert.strategy.trigger.baseline_start_time|date:"Y年n月d日 H:i:s" }} 到　{{ alert.strategy.trigger.baseline_end_time|date:"Y年n月d日 H:i:s" }}　<br>
统计时间范围：{{ alert.strategy.trigger.baseline_end_time|date:"Y年n月d日 H:i:s" }} 到 {{ alert.strategy.trigger.end_time|date:"Y年n月d日 H:i:s" }}<br>
触发条件： {{ alert.strategy.trigger.compare_desc_text }}<br>
基线值：{{ alert.strategy.trigger.baseline_base_value}} <br>
当前值：{{ alert.result.value }} <br>

{% elif alert.strategy.name == "spl_query" %}
触发条件：{{ alert.strategy.trigger.compare_desc_text }}<br>

{% if alert.result.columns %}
告警结果：<br>
<table>
<tr>
  {% for k in alert.result.columns %}
  <td>{{ k.name}}</td>
  {% endfor %}
</tr>
  {% for result_row in alert.result.hits %}
  <tr>
    {% for k in alert.result.columns %}
       {% for rk, rv in result_row.items %}
         {% if rk == k.name %}
         <td>{{ rv }}</td>
         {% endif %}
       {% endfor %}
    {% endfor %}
  </tr>
  {% endfor %}
{% endif %}
</table>


{% endif %}

{% if alert.result.extend_total > 0 or alert.result.extend_result_total_hits > 0 or alert.result.extend_result_sheets_total %}
<br>
===========================================================<br>
{%if alert.result.is_extend_query_timechart and alert.graph_enabled %}
<br><img src="cid:timechart_trend"/><br><br>
{% endif%}

当前扩展搜索检索了{{ alert.result.extend_result_total_hits }}条数据，现返回{{ alert.result.extend_result_sheets_total }}个结果<br>
时间范围: {{ alert.strategy.trigger.start_time|date:"Y年n月d日 H:i:s" }}到{{ alert.strategy.trigger.end_time|date:"Y年n月d日 H:i:s" }}<br>
查询语句: {{ alert.search.extend_query }}<br>
过滤条件: {{ alert.search.extend_filter}}<br><br>

<table>
{% if alert.result.extend_hits %}
{% if "raw_message" in alert.result.extend_hits.0.keys %}
{% for ext in alert.result.extend_hits %}
<tr><td>{{ ext.raw_message }}</td></tr>
{% endfor %}

{% elif "_count" in alert.result.extend_hits.0.keys %}

{% for ext in alert.result.extend_hits %}
{% for sis in ext.source %}
<tr><td>{{ sis.raw_message }}</td></tr>
{% endfor %}
<tr><td>---------------------</td></tr>
{% endfor %}

{% else %}
<tr>
{% for ks in alert.result.extend_hits.0.keys %}
<td>{{ ks }}</td>
{% endfor %}
</tr>
{% for ext in alert.result.extend_hits %}
    <tr>
    {% for the_key in ext.keys %}
    {% for key, value in ext.items %}
       {% if key == the_key %}
       <td>{{value}}</td>
       {% endif %}
    {% endfor %}
    {% endfor %}
    </tr>
{% endfor %}

{% endif %}

{% endif %}
</table>

{% endif %}

{% endif %}
                """,
                "style": {
                    "rows": 30,
                    "cols": 60
                }
            }
            ]
        }

# 发送GET请求，可以传入frontend的地址和接口，向Frontend发送请求
def http_get(url, params):
    re_logger.info("url is %s" % (url))
    re_logger.info("params is %s" % (params))

    url_params = urllib.parse.urlencode(params)
    re_logger.info("whole url is %s%s%s" % (url, '?', url_params))

    req = urllib.request.Request(url = '%s%s%s' % (url,'?',url_params))
    res = urllib.request.urlopen(req)
    res = res.read()
    re_logger.info("response is %s" % (res))
    return res

def _web_conf_obj():
    confobj = {}
    try:
        cf = configparser.ConfigParser()
        real_path = os.getcwd() + '/config'
        cf.read(real_path + "/yottaweb.ini")
        for section in cf.sections():
            confobj[section] = {}
            for k,v in cf.items(section):
                confobj[section][k] = v
    except Exception as e:
        log_and_reply(logging.ERROR, ("_yottaweb_conf_obj get failed!"))
    return confobj

def _render(conf_obj, tmpl_str):
    t = Template(tmpl_str)
    c = Context(conf_obj)
    _content = t.render(c)
    return _content

def content(params, alert, isHandle = False):
    re_logger.info("content params is %s" % (params))
    template_str = params.get('configs')[2].get('value')
    conf_obj = {'alert': alert, 'web_conf': _web_conf_obj()}
    _content = _render(conf_obj, template_str)
    re_logger.info("isHandle is %s" % (isHandle))

    if not isHandle:
        _content = add_graph_to_text(params, _content)
    re_logger.info("content result is %s" % (_content))
    return _content

def connect_method(use_ssl, mail_host, smtp_port):
    if use_ssl == "yes":
        s = smtplib.SMTP_SSL()
    else:
        s = smtplib.SMTP()
    s.connect(mail_host,smtp_port)
    return s

# 样例2就是默认的发送方式
def common_method(use_ssl, mail_host, smtp_port):
    if use_ssl == "yes":
        s = smtplib.SMTP_SSL(mail_host, smtp_port)
    else:
        s = smtplib.SMTP(mail_host, smtp_port)
    return s

def starttls_method(use_ssl, mail_host, smtp_port):
    if use_ssl == "yes":
        s = smtplib.SMTP_SSL(mail_host, smtp_port)
    else:
        s = smtplib.SMTP(mail_host, smtp_port)
    s.starttls()
    return s
        

send_email_method = {"connect": connect_method, "common": common_method, "starttls": starttls_method}


# 预览插入趋势图
def add_graph_to_text(params, content):
    graph_path = ""
    if "timechart_trend_path" in params:
        graph_path = params.get('timechart_trend_path')
        re_logger.info("graph_path is %s" % (graph_path))

        fp = open(graph_path, 'rb')
        base64_data = base64.b64encode(fp.read())
        fp.close()
        imageHtml = "<img src=\"data:image/jpg;base64,%s\" style=\"width:700px\"/><br><br>" % (base64_data)
        content = content.replace("<br><img src=\"cid:timechart_trend\"/><br><br>", imageHtml)
    else:
        #如果没有图片，这里就去掉显示图片的地方，否则会有一个图裂，但是不知道需不需要保留这个图裂，以作提示
        content = content.replace("<br><img src=\"cid:timechart_trend\"/><br><br>", "")

    re_logger.info("content replace is %s" % (content))
    return content


def handle(params, alert):
    # print "###########################mail params: ",params
    # print "###########################mail alert: ", alert

    # render subject
    subject_tmpl = params.get('configs')[0].get('value')
    subject_conf_obj = {'alert': alert}
    subject = _render(subject_conf_obj, subject_tmpl)

    re_logger.info("configs[1] is %s" % (params.get('configs')[1]))
    receivers = params.get('configs')[1].get('value').strip(',').split(',')
    re_logger.info("receivers are %s" % (receivers))


    web_conf = _web_conf_obj()
    url= web_conf['frontend']['frontend_url'].strip(',').split(',')[0]
    token = alert.get('_alert_domain_token')
    operator = alert.get('_alert_owner_name')
    re_logger.info("token is %s" % (token))
    re_logger.info("operator is %s" % (operator))
    re_logger.info("frontend url is %s" % (url))

    # Frontend只有通过某个用户分组id获取某个分组的用户，目前没有批量接口。
    account_emails_list = []
    for receiver in receivers:     # 循环获取
        re_logger.info("receiver is %s" % (receiver))
        if '@' in receiver:
            account_emails_list = account_emails_list + [receiver]
            re_logger.info("account_emails_list is %s" % (account_emails_list))
        else:
            get_account_params = {'act':'get_account_by_user_group_id','operator':operator,'token':token,'user_group_id':receiver}
            response = json.loads(http_get(url, get_account_params))
            re_logger.info("response is %s" % (response))
            if "accounts" in response:
                accounts = response['accounts']
                re_logger.info("accounts is %s" % (accounts))
                #判断email有无
                for account in accounts:
                    if "email" in account:
                        account_emails_list = account_emails_list + [account.get('email')]
                re_logger.info("account_emails_list is %s" % (account_emails_list))
            else:
                log_and_reply(logging.WARNING, ("no user group for %s" % (receiver)))

    #虽然注册用户时，邮箱不能重复，但是这里还是去重一下
    account_emails = list(set(account_emails_list))
    #转化字符串
    receiver_str = ','.join(account_emails)
    re_logger.info("receiver_str is %s" % (receiver_str))

    #获取趋势图路径
    graph_path = ""
    #扩展搜索不是timechart的也不发送附件图片
    if ("result" in alert) and ("is_extend_query_timechart" in alert.get("result")):
        is_extend_query_timechart = alert.get("result").get("is_extend_query_timechart")
        if ("timechart_trend_path" in params) and is_extend_query_timechart:
            graph_path = params.get('timechart_trend_path')

    re_logger.info("graph_path is %s" % (graph_path))

    _content = content(params, alert, True)
    subject = subject + "#token#" +token
    send_mail(subject, receiver_str, _content, graph_path)

def send_mail(subject, receiver, content, graph_path):
    subject_arr = subject.split("#token#")
    subject = subject_arr[0]
    token = ""
    try:
        token = subject_arr[1]
        cf = configparser.ConfigParser()
        real_path = os.getcwd() + '/config'
        cf.read(real_path + "/yottaweb.ini")
        use_ssl_ini = cf.get('email', 'use_ssl')
        need_login_ini = cf.get('email', 'need_login')
        send_address_ini = cf.get('email', 'send')
        smtp_pwd_ini = cf.get('email', 'passwd')
        smtp_port_ini = cf.get('email', 'smtp_port')
        email_user_ini = cf.get('email', 'user')
        smtp_server_ini = cf.get('email', 'smtp_server')
        use_ssl = ''
        need_login = ''
        send_address = ''
        smtp_pwd = ''
        smtp_port = ''
        email_user = ''
        smtp_server = ''
        
        all_ori_conf = MyUtils().get_key_config(token, 'all').get("data")
        
        if all_ori_conf:
            use_ssl = all_ori_conf.get('email_email_use_ssl')
            need_login = all_ori_conf.get('email_email_need_login')
            send_address = str(all_ori_conf.get('email_send'))
            smtp_pwd = all_ori_conf.get('email_passwd')
            smtp_port = str(all_ori_conf.get('email_smtp_port'))
            email_user = str(all_ori_conf.get('email_user')) if all_ori_conf.get('email_user') else all_ori_conf.get('email_user')
            smtp_server = str(all_ori_conf.get('email_smtp_server'))
            if not (send_address and smtp_pwd and smtp_port and smtp_server and email_user):
                use_ssl = use_ssl_ini
                need_login = need_login_ini
                send_address = send_address_ini
                smtp_pwd = smtp_pwd_ini
                smtp_port = smtp_port_ini
                email_user = email_user_ini
                smtp_server = smtp_server_ini
            if email_user == 'sender' or not email_user:
                email_user = send_address
    except Exception as e:
        log_and_reply(logging.ERROR, ("alert_plugins_config get failed!"))
        use_ssl = 'no'
        need_login = 'yes'
        send_address = 'notice@yottabyte.cn'
        smtp_pwd = ''
        smtp_port = ''
        smtp_server = ''
    re_logger.info("alert_send_mail_conf: %s" % (send_address))
    sub = subject
    content = content
    mail_to_list = receiver.split(',')
    if not mail_to_list:
        return
    mail_host = smtp_server
    mail_address = send_address
    mail_pass = smtp_pwd
    mail_user = email_user
    #
    # to_list:发给谁
    # sub:主题
    # content:内容
    # send_mail("sub","content")

    #
    main_msg = MIMEMultipart()
    me = mail_address
    msg = MIMEText(content, _subtype='html', _charset='gb18030')  # 创建一个实例，这里设置为html格式邮件
    main_msg.attach(msg)
    main_msg['Subject'] = sub
    main_msg['From'] = me
    main_msg['To'] = ";".join(mail_to_list)

    contype = 'application/octet-stream'
    maintype, subtype = contype.split('/', 1)

    # 如果趋势图路径是空，则跳过，不附带图片
    if graph_path != "":
        target_file = graph_path
        data = open(target_file, 'rb')
        file_msg = MIMEBase(maintype, subtype)
        file_msg.set_payload(data.read())
        data.close()
        encoders.encode_base64(file_msg)
        #设置附件头
        basename = os.path.basename(target_file)
        file_msg.add_header('Content-Disposition', 'attachment', filename = basename)
        main_msg.attach(file_msg)

        #正文也增加图片，但是一个流只能增加一种，所以不能与附件合并
        fp = open(target_file, 'rb')
        image_msg = MIMEImage(fp.read(),subtype)
        fp.close()
        image_msg.add_header('Content-ID', '<timechart_trend>')
        main_msg.attach(image_msg)


    try:
        smtp = send_email_method.get(send_type)(use_ssl, mail_host, smtp_port)
        if need_login == "yes":
            smtp.login(mail_user, mail_pass)

        # re_logger.error(main_msg.as_string())
        smtp.sendmail(me, mail_to_list, main_msg.as_string())
        smtp.close()
        log_and_reply(logging.INFO, ("Send email[ %s ] of report successful!" % (sub)))
        return True
    except Exception as e:
        log_and_reply(logging.ERROR, ("Send mail [ %s ] Error: %s" % (sub, str(e))))
        return False

# 既在日志中打印，又在执行结果中显示
def log_and_reply(log_level, comment):
    global reply_content
    log_content.get(log_level)(comment)
    reply_content = '%s%s%s' % (reply_content, "\n", comment)

# 获取执行结果的接口
def execute_reply(params, alert):
    re_logger.info("reply_content start")
    handle(params, alert)
    re_logger.info("reply_content: %s" % (reply_content))
    return reply_content
