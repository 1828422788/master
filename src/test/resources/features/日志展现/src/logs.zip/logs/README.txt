1. Upload the logs before tests:  
   Open 本地上传
   -- auto_sample_chart:
    date should be changed to Today's
	tag: auto_sample_chart
	appname: apache

   -- auto_sample_display:
    date should be changed to Today's
	tag: auto_sample_display
	appname: apache

   -- auto_sankey:
	tag: auto_sankey
	appname: json 
	
   -- vendors:
    tag: vendors_461
	appname: vendors
